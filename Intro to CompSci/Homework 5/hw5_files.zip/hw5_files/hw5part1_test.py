
import hw5util

if __name__ == "__main__":
    games, players, predictions = hw5util.read_predictions('predictions_short.txt')
    print ("Games:")
    print (games)
    print ("Players:")
    print (players)
    print ("Predictions:")
    print (predictions)
