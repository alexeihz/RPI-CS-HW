import hw4_util

data = hw4_util.read_university_file("university_data.csv")

print (data[0][:5])
print (data[400][:5])
print (data[1671][:5])
