HOMEWORK 2: FOOTBALL CLASSES


NAME:  < insert name >


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  < insert # hours >



DESCRIPTION OF YOUR CREATIVE STATISTIC:
Please be concise!



SAMPLE COMMAND LINE & OUTPUT OF YOUR CREATIVE STATISTIC:
Paste a small portion or your output here, and include the full output
file in your submission.  Also include your input dataset in the .zip
file if it is not one of the provided ones.



MISC. COMMENTS TO GRADER:  
Optional, please be concise!
