HOMEWORK 6: INVERSE SLITHERLINK CONTEST


NAME:  < insert name >



COLLABORATORS AND OTHER RESOURCES:
< insert collaborators / resources >



DESCRIPTION OF ANY PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:
(please be concise!)



OPTIONAL: NEW SLITHERLINK PUZZLE OR INVERSE SLITHERLINKPATH FILES
Be sure to name the files puzzle_smithj.txt and inverse_smithj.txt
Describe your goal in the design of this input files.



SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
# of solutions & approximate wall clock running time for different
puzzles for a single solution or all solutions.
